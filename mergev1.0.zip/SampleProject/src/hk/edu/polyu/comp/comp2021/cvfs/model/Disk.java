package hk.edu.polyu.comp.comp2021.cvfs.model;

public class Disk {
    private int size;
    private Directory rootDir;
    public Disk(int diskSize){
        size=diskSize;
        rootDir=new Directory("Disk");
    }
    public Directory getDir(){
        return rootDir;
    }
    public int getSize(){return size;}
    //req14
    public void rSearch(Criteria criteria) {
        int totalFiles = rSearch(rootDir, criteria, 0);
        System.out.println("Total files: " + totalFiles);
    }
    private int rSearch(Directory dir, Criteria criteria, int totalSize) {
        int numFiles = 0;
        for (Object obj : dir.getMap().values()) {
            if (obj instanceof Document) {
                Document doc = (Document) obj;
                if (criteria.matches(doc)) {
                    System.out.println("Document: " + doc.getDocName() + ", Size: " + doc.getSize());
                    numFiles++;
                    totalSize += doc.getSize();
                }
            } else if (obj instanceof Directory) {
                numFiles += rSearch((Directory) obj, criteria, totalSize);
            }
        }
        return numFiles;
    }
    // Direct search for files based on criteria
    public void search(Criteria criteria) {
        int totalFiles = search(rootDir, criteria, 0);
        System.out.println("Total files: " + totalFiles);
    }
    private int search(Directory dir, Criteria criteria, int totalSize) {
        int numFiles = 0;
        for (Object obj : dir.getMap().values()) {
            if (obj instanceof Document) {
                Document doc = (Document) obj;
                if (criteria.matches(doc)) {
                    System.out.println("Document: " + doc.getDocName() + ", Size: " + doc.getSize());
                    numFiles++;
                    totalSize += doc.getSize();
                }
            }
        }
        return numFiles;
        
    }
}
