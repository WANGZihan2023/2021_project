package hk.edu.polyu.comp.comp2021.cvfs.model;

import java.util.Map;

public class Criteria {
    private String criName;
    private String attrName;
    private String op;
    private String val;
    private static Map<String,Criteria> name2cri;
}
