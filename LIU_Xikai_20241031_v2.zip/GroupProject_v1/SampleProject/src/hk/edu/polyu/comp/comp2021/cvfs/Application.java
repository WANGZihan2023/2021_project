package hk.edu.polyu.comp.comp2021.cvfs;

import hk.edu.polyu.comp.comp2021.cvfs.model.CVFS;
import hk.edu.polyu.comp.comp2021.cvfs.model.Directory;
import hk.edu.polyu.comp.comp2021.cvfs.model.Disk;
import hk.edu.polyu.comp.comp2021.cvfs.model.Document;

import java.util.Scanner;
import java.util.Stack;

public class Application {

    public static void main(String[] args){
        CVFS cvfs = new CVFS();
        // Initialize and utilize the system
        Stack<Directory> stack=new Stack<>();//存储所有路径
        Scanner scanner = new Scanner(System.in);
        String command;
        String[] commandWords;

        System.out.println("Any command or 'quit' to quit.");

        while (true) {
            System.out.print("Command: ");
            command = scanner.nextLine();
            commandWords=command.split("\\s+");

            if (command.equalsIgnoreCase("quit")) {
                System.out.println("Terminate the execution of the system.");
                break;
            }

            if (commandWords[0].equals("newDisk")){
                int size=Integer.parseInt(commandWords[1]);
                Disk disk=new Disk(size);
                cvfs.setDisk(disk);
                cvfs.setDir(cvfs.getDisk().getDir());
                stack.push(cvfs.getDir());
                System.out.println("New disk created successfully.");
            }

            if (commandWords[0].equals("newDoc")){
                Document doc=new Document(commandWords[1],commandWords[2],commandWords[3]);
                cvfs.getDir().put(commandWords[1],doc);
                System.out.println("New document created successfully.");
            }

            if (commandWords[0].equals("newDir")){
                Directory dir=new Directory(commandWords[1]);
                cvfs.getDir().put(commandWords[1],dir);
                System.out.println("New directory created successfully.");
            }

            if (commandWords[0].equals("delete")){
                cvfs.getDir().delete(commandWords[1]);
                System.out.println("Delete successfully.");
            }

            if (commandWords[0].equals("changeDir")){
                if(cvfs.getDir().get(commandWords[1])!=null){
                    cvfs.setDir((Directory) cvfs.getDir().get(commandWords[1]));
                    stack.push(cvfs.getDir());
                }else if(commandWords[1].equals("..") && !cvfs.getDir().toString().equals("Disk")){//dirName是..并且workingDir不是根目录
                    stack.pop();
                    cvfs.setDir(stack.peek());
                }
            }
            System.out.println(cvfs.getDir().toString()+">");
        }

        scanner.close();
    }
}
