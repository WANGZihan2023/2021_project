package hk.edu.polyu.comp.comp2021.cvfs.model;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class Directory {
    private String DirStr;
    private Map<String,Object> map;
    private int size;
    public Directory(String dirname){
        DirStr=dirname;
        map= new HashMap<>();
        size=40;
    }
    public void put(String name,Document doc){
        map.put(name,doc);
        size+=doc.getSize();
    }
    public void put(String name,Directory dir){
        map.put(name,dir);
        size+=dir.getSize();
    }
    public void delete(String name){
        int objSize;
        if (map.get(name).getClass()==Document.class){
            Document obj=(Document) map.get(name);
            objSize=obj.getSize();
        }else{
            Directory obj=(Directory) map.get(name);
            objSize=obj.getSize();
        }
        size-=objSize;
        map.remove(name);
    }
    public Object get(String name){
        return map.get(name);
    }
    public int getSize(){
        return size;
    }
    public String toString(){
        return DirStr;
    }
    public String listString(){
        return "Name: "+DirStr+" size: "+size;
    }
    public void list(){
        int num=0,si=0;
        for(Map.Entry<String,Object> entry: map.entrySet()){
            if(entry.getValue() instanceof Document){
                System.out.println(  ( (Document)entry.getValue() ).listString()  );
                si+=((Document)entry.getValue()).getSize();
            }else{
                System.out.println(  ( (Directory)entry.getValue() ).listString()  );
                si+=((Directory)entry.getValue()).getSize();
            }
            num++;
        }
        System.out.println("Total number: "+num+" Total size: "+si);
    }

    public void rList(int times){
        int num=0,si=0;
        for(Map.Entry<String,Object> entry: map.entrySet()){
            if(entry.getValue() instanceof Document){
                System.out.println(  "  ".repeat(times)+( (Document)entry.getValue() ).listString()  );
                si+=((Document)entry.getValue()).getSize();
            }else{
                System.out.println(  "  ".repeat(times)+( (Directory)entry.getValue() ).listString()  );
                ((Directory)entry.getValue()) .rList(times+1);
                si+=((Directory)entry.getValue()).getSize();
            }
            num++;
        }
        System.out.println("  ".repeat(times)+"Total number: "+num+" Total size: "+si);
    }

    public void rList4Save(int times){
        int num=0,si=0;
        for(Map.Entry<String,Object> entry: map.entrySet()){
            if(entry.getValue() instanceof Document){
                System.out.println(  "  ".repeat(times)+( (Document)entry.getValue() ).listString()+" "+( (Document)entry.getValue() ).getDocContent()  );
                si+=((Document)entry.getValue()).getSize();
            }else{
                System.out.println(  "  ".repeat(times)+( (Directory)entry.getValue() ).listString()  );
                ((Directory)entry.getValue()) .rList4Save(times+1);
                si+=((Directory)entry.getValue()).getSize();
            }
            num++;
        }
        System.out.println("  ".repeat(times)+"Total number: "+num+" Total size: "+si);
    }

    public void save(String path){
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(outputStream);
        PrintStream originalOut = System.out;
        System.setOut(printStream);

        this.rList4Save(0);

        System.setOut(originalOut);
        String capturedOutput = outputStream.toString();

        File file =new File(path);
        try{
            if (file.createNewFile()) {
                System.out.println("File created successfully. " + path);
            } else {
                System.out.println("File already exist. " + path);
            }
            try (FileWriter writer = new FileWriter(file)) {
                writer.write(capturedOutput); // 写入内容到文件
                System.out.println("Content written to file. " + path);
            }
        }catch (IOException e) {
            System.err.println("Error" + e.getMessage());
        }
    }
    public Map<String,Object> getMap(){
        return map;
    }
    public String getDirStr(){
        return DirStr;
    }
    public void setDirStr(String dirname){
        DirStr=dirname;
    }
    public void setMap(Map<String,Object> map){
        this.map=map;
    }
    public void setSize(int size){
        this.size=size;
    }
}
