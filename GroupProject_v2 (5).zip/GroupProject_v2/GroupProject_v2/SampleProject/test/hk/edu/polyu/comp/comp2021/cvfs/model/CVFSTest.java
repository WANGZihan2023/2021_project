package hk.edu.polyu.comp.comp2021.cvfs.model;

import org.junit.Test;

public class CVFSTest {

    @Test
    public void testCVFS(){
        CVFS cvfs = new CVFS();
        Disk disk=new Disk(1024);
        cvfs.setDisk(disk);
        Disk got=cvfs.getDisk();
        cvfs.setDir(disk.getDir());
        Directory gotD=cvfs.getDir();
        assert true;
    }

}