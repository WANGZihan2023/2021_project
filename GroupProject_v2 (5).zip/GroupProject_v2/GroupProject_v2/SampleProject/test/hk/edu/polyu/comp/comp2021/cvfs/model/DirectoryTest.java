package hk.edu.polyu.comp.comp2021.cvfs.model;
import org.junit.Test;
public class DirectoryTest {
    @Test
    public void testDirectory(){
        Document doc4put=new Document("doc4put","txt","111");
        Directory dir =new Directory("dir1");
        Directory dir4put=new Directory("dir4put");
        dir.put(doc4put.getDocName(), doc4put);
        dir.put(dir4put.getDirStr(),dir4put);
        dir.delete(doc4put.getDocName());
        dir.get(dir4put.getDirStr());
        dir.getSize();
        dir.listString();
        dir.list();
        dir.rList(0);
        dir.save("Disk4Test");
        dir.getMap();
        dir.getDirStr();
        dir.setDirStr("dir1");
        Criteria cri=new Criteria("aa","name","contains","\"do\"");
        dir.search(cri);
        dir.rSearch(cri,0);
        dir.getAllSize();
    }
}
