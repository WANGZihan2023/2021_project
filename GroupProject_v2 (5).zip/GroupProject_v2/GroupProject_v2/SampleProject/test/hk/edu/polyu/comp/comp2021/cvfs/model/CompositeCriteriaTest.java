package hk.edu.polyu.comp.comp2021.cvfs.model;
import org.junit.Test;
public class CompositeCriteriaTest {
    @Test
    public void testCompositeCriteria(){
        Criteria aa=new Criteria("aa","name","contains","\"do\"");
        Criteria bb=new Criteria("bb","type","equals","\"txt\"");
        Criteria cc=new Criteria("cc","size",">","20");
        compositeCriteria bn=new compositeCriteria("bn",aa,"&&",bb);
        bn.getCriteria1();
        bn.getCriteria2();
        bn.getLogicOp();
        bn.print();
        Document doc=new Document("doc1","txt","111");
        bn.matches(doc);
    }
}
