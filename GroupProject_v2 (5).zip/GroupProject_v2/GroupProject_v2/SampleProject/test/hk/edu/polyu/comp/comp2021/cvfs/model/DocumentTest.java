package hk.edu.polyu.comp.comp2021.cvfs.model;

import org.junit.Test;
public class DocumentTest {
    @Test
    public void testDocument(){
        Document doc=new Document("doc1","txt","111");
        doc.getSize();
        doc.getDocContent();
        doc.listString();
        doc.getDocName();
        doc.getDocType();
    }
}
