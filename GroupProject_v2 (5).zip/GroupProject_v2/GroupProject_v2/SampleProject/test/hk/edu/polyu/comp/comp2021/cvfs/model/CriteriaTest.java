package hk.edu.polyu.comp.comp2021.cvfs.model;
import org.junit.Test;
public class CriteriaTest {
    @Test
    public void testCriteria(){
        Criteria aa=new Criteria("aa","name","contains","\"do\"");
        Criteria bb=new Criteria("bb","type","equals","txt");
        Criteria cc=new Criteria("cc","size",">","20");
        Criteria de=new Criteria("de","size","<","20");
        Criteria df=new Criteria("df","size",">=","20");
        Criteria dg=new Criteria("dg","size","<=","20");
        Criteria dh=new Criteria("dh","size","==","20");
        Criteria di=new Criteria("di","size","!=","20");
        Criteria.notOp("!=");
        aa.getCriName();
        aa.getAttrName();
        aa.getOp();
        aa.getVal();
        Document doc=new Document("doc1","txt","111");
        aa.matches(doc);
        cc.matches(doc);
        de.matches(doc);
        df.matches(doc);
        dg.matches(doc);
        dh.matches(doc);
        di.matches(doc);

        Directory dir=new Directory("dir1");
        aa.matches(dir);
        cc.matches(dir);
        de.matches(dir);
        df.matches(dir);
        dg.matches(dir);
        dh.matches(dir);
        di.matches(dir);

        aa.print();
    }
}
