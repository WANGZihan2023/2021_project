package hk.edu.polyu.comp.comp2021.cvfs.model;

import org.junit.Test;
public class DiskTest {
    @Test
    public void testDiskGetSize(){
        Disk disk=new Disk(1024);
        disk.getSize();
    }
}
