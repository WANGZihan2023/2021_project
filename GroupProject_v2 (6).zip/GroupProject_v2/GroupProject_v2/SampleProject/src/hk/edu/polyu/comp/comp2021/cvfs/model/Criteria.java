package hk.edu.polyu.comp.comp2021.cvfs.model;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class Criteria {
    private String criName;
    private String attrName;
    private String op;
    private String val;
    public static Map<String,Criteria> name2cri = new HashMap<>();

    public Criteria(String criName, String attrName, String op, String val) {
        setCriName(criName);
        setAttrName(attrName);
        setOp(op);
        setVal(val);
        name2cri.put(criName,this);
    }


    public String getCriName() {
        return criName;
    }
    public void setCriName(String criName) {
        this.criName = criName;
    }
    public String getAttrName() {
        return attrName;
    }
    public void setAttrName(String attrName) {
        if (attrName.equals("name") || attrName.equals("type") || attrName.equals("size")) {
            this.attrName = attrName;
        } else {
            System.out.println("Invalid attrName.");
        }
    }
    public String getOp() {
        return op;
    }
    public void setOp(String op) {
        if (attrName.equals("name") && op.equals("contains")) {
            this.op = op;
        } else if (attrName.equals("type") && op.equals("equals")) {
            this.op = op;
        } else if (attrName.equals("size") && (op.equals(">") || op.equals("<") || op.equals(">=") || op.equals("<=") || op.equals("==") || op.equals("!="))) {
            this.op = op;
        } else {
            System.out.println("Invalid op for attrName.");
        }
    }
    public String getVal() {
        return val;
    }
    public void setVal(String val) {
        if (attrName.equals("name") && val.startsWith("\"") && val.endsWith("\"")) {
            this.val = val;
        } else if (attrName.equals("type") && val.startsWith("\"") && val.endsWith("\"")) {
            this.val = val;
        } else if (attrName.equals("size") && val.matches("\\d+")) {
            this.val = val;
        } else {
            System.out.println("Invalid val for attrName.");
        }
    }

    public static String notOp(String op){
        String notOp = "";
        if (Objects.equals(op, "<")){
            notOp =  ">=";
        }
        if (Objects.equals(op, ">")){
            notOp =  "<=";
        }
        if (Objects.equals(op, ">=")){
            notOp =  "<";
        }
        if (Objects.equals(op, "<=")){
            notOp =  ">";
        }
        if (Objects.equals(op, "==")){
            notOp =  "!=";
        }
        if (Objects.equals(op, "!=")){
            notOp =  "==";
        }
        return notOp;
    }




    public static Criteria getCriteria(String attrName){
        return name2cri.get(attrName);
    }

    public static Collection<Criteria> getAllCriteria(){return name2cri.values();}

    public boolean matches(Document doc) {
        if (this instanceof compositeCriteria){
            if (((compositeCriteria) this).getLogicOp().equals("&&")){
                return ((compositeCriteria) this).getCriteria1().matches(doc) && ((compositeCriteria) this).getCriteria2().matches(doc);
            }else{
                return ((compositeCriteria) this).getCriteria1().matches(doc) || ((compositeCriteria) this).getCriteria2().matches(doc);
            }

        }
        switch (attrName) {
            case "name":
                return op.equals("contains") && doc.getDocName().contains(val.replace("\"", ""));
            case "type":
                return op.equals("equals") && doc.getDocType().equals(val.replace("\"", ""));
            case "size":
                int docSize = doc.getSize();
                int criteriaValue = Integer.parseInt(val);
                switch (op) {
                    case ">":
                        return docSize > criteriaValue;
                    case "<":
                        return docSize < criteriaValue;
                    case ">=":
                        return docSize >= criteriaValue;
                    case "<=":
                        return docSize <= criteriaValue;
                    case "==":
                        return docSize == criteriaValue;
                    case "!=":
                        return docSize != criteriaValue;
                    default:
                        return false;
                }
            default:
                return false;
        }
    }
    public boolean matches(Directory dir) {
        if (this instanceof compositeCriteria){
            if (((compositeCriteria) this).getLogicOp().equals("&&")){
                return ((compositeCriteria) this).getCriteria1().matches(dir) && ((compositeCriteria) this).getCriteria2().matches(dir);
            }else{
                return ((compositeCriteria) this).getCriteria1().matches(dir) || ((compositeCriteria) this).getCriteria2().matches(dir);
            }

        }
        switch (attrName) {
            case "name":
                return op.equals("contains") && dir.toString().contains(val.replace("\"", ""));
            case "size":
                int dirSize = dir.getSize();
                int criteriaValue = Integer.parseInt(val);
                switch (op) {
                    case ">":
                        return dirSize > criteriaValue;
                    case "<":
                        return dirSize < criteriaValue;
                    case ">=":
                        return dirSize >= criteriaValue;
                    case "<=":
                        return dirSize <= criteriaValue;
                    case "==":
                        return dirSize == criteriaValue;
                    case "!=":
                        return dirSize != criteriaValue;
                    default:
                        return false;
                }
            default:
                return false;
        }
    }
    public void print(){
        if (this instanceof compositeCriteria){
            ((compositeCriteria) this).getCriteria1().print();
            System.out.print( ((compositeCriteria) this).getLogicOp() + " ");
            ((compositeCriteria) this).getCriteria2().print();
        }else{
            System.out.print(this.getAttrName() +" "+ this.getOp() +" " + this.getVal()+" ");
        }

    }
    public static void save(String path){
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(outputStream);
        PrintStream originalOut = System.out;
        System.setOut(printStream);

        for (Criteria criteria : Criteria.getAllCriteria()) {
            if (criteria instanceof compositeCriteria) {
                System.out.print(criteria.criName+" ");
                System.out.print( ((compositeCriteria) criteria).getCriteria1().getCriName()+" "+((compositeCriteria) criteria).getLogicOp() +" "+((compositeCriteria) criteria).getCriteria2().getCriName());
                System.out.println("");
            } else if(criteria.getCriName().equals("IsDocument")){
                System.out.println("IsDocument");
            }else {
                System.out.print(criteria.criName+" ");
                System.out.println(criteria.getAttrName() +" "+ criteria.getOp() +" " + criteria.getVal());
            }
        }

        System.setOut(originalOut);
        String capturedOutput = outputStream.toString();

        File file =new File(path);
        try{
            if (file.createNewFile()) {
                System.out.println("File created successfully. " + path);
            } else {
                System.out.println("File already exist. " + path);
            }
            try (FileWriter writer = new FileWriter(file)) {
                writer.write(capturedOutput); // 写入内容到文件
                System.out.println("Content written to file. " + path);
            }
        }catch (IOException e) {
            System.err.println("Error" + e.getMessage());
        }
    }

    public static void load(String path){
        try {
            List<String> lines = Files.readAllLines(Paths.get(path));
            List<String[]> Ls=new ArrayList<>();
            for(String line:lines){
                if(line.split(" ").length==1)continue;//无视掉IsDocument
                String[] words=line.split(" ");
                Ls.add(words);
            }

            while(Ls.isEmpty()==false){
                Iterator<String[]> iterator=Ls.iterator();
                while(iterator.hasNext()){
                    String[] words=iterator.next();
                    if(words[2].equals("&&") || words[2].equals("||")){
                        String criName1 = words[0];
                        String criName3 = words[1];
                        String logicOp = words[2];
                        String criName4 = words[3];
                        Criteria criteria3 = Criteria.getCriteria(criName3);
                        Criteria criteria4 = Criteria.getCriteria(criName4);

                        if (criteria3 != null && criteria4 != null) {
                            if (logicOp.equals("&&") || logicOp.equals("||")) {
                                Criteria binaryCriteria = new compositeCriteria(criName1, criteria3, logicOp, criteria4);
                                System.out.println("Binary criterion created successfully.");
                                iterator.remove();
                            } else {

                            }
                        } else {

                        }
                        continue;
                    }
                    String criName = words[0];
                    String attrName = words[1];
                    String op = words[2];
                    String val = words[3];
                    Criteria criteria = new Criteria(criName,attrName,op,val);
                    iterator.remove();
                }
            }



        } catch (IOException e) {
            System.err.println("load error"+e.getMessage());
        }
    }


}