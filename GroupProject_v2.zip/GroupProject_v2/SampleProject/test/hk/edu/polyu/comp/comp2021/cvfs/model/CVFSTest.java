package hk.edu.polyu.comp.comp2021.cvfs.model;

import org.junit.Test;

public class CVFSTest {

    @Test
    public void testCVFSConstructor(){
        CVFS cvfs = new CVFS();

        assert true;
    }

}