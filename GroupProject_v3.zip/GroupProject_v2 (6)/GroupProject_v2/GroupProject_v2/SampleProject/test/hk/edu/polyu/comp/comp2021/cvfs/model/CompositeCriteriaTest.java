package hk.edu.polyu.comp.comp2021.cvfs.model;
import org.junit.Test;
public class CompositeCriteriaTest {
    @Test
    public void testCompositeCriteriaConstructor() {
        Criteria aa = new Criteria("aa", "name", "contains", "\"do\"");
        Criteria bb = new Criteria("bb", "type", "equals", "\"txt\"");
        Criteria cc = new Criteria("cc", "size", ">", "20");
        compositeCriteria bn = new compositeCriteria("bn", aa, "&&", bb);
    }
    @Test
    public void testCompositeCriteriaprint() {
        Criteria a1 = new Criteria("a1", "name", "contains", "\"do\"");
        Criteria a2 = new Criteria("a2", "type", "equals", "\"txt\"");
        compositeCriteria a3 = new compositeCriteria("a3", a1, "&&", a2);
        a3.print();
    }
    @Test
    public void testCompositematches(){
        Criteria b1 = new Criteria("b1", "name", "contains", "\"do\"");
        Criteria b2 = new Criteria("b2", "type", "equals", "\"txt\"");
        compositeCriteria b3 = new compositeCriteria("b3", b1, "&&", b2);
        Document doc=new Document("doc1","txt","111");
        b3.matches(doc);
    }
    @Test
    public void testCompositeGetCri(){
        Criteria c1 = new Criteria("c1", "name", "contains", "\"do\"");
        Criteria c2 = new Criteria("c2", "type", "equals", "\"txt\"");
        compositeCriteria c3 = new compositeCriteria("c3", c1, "&&", c2);
        c3.getCriteria1();
        c3.getCriteria2();
        c3.getLogicOp();
    }
}
