package hk.edu.polyu.comp.comp2021.cvfs.model;
import org.junit.Test;
public class DirectoryTest {
    @Test
    public void testDirectoryConstructor(){
        Directory dircon =new Directory("dircon");
    }
    @Test
    public void testDirectoryPut(){
        Document doc4put=new Document("doc4put","txt","111");
        Directory dir =new Directory("dir1");
        Directory dir4put=new Directory("dir4put");
        dir.put(doc4put.getDocName(), doc4put);
        dir.put(dir4put.getDirStr(),dir4put);
        dir.get(dir4put.getDirStr());
        dir4put.list();
        dir4put.rList(0);

        dir.delete(dir4put.getDirStr());
    }

    @Test
    public void testDirectory(){
        Document doc4put=new Document("doc4put","txt","111");
        Directory dir =new Directory("dir1");
        Directory dir4put=new Directory("dir4put");
        dir.put(doc4put.getDocName(), doc4put);
        dir.put(dir4put.getDirStr(),dir4put);
        dir.get(dir.getDirStr());
        dir.getSize();
        dir.list();
        dir.rList(0);
        dir.save("Disk4Test");
        dir.getMap();
        dir.getDirStr();
        dir.setDirStr("dir1");
        Criteria cri=new Criteria("aa","name","contains","\"do\"");
        dir.search(cri);
        dir.rSearch(cri,0);
        dir.getAllSize();
        dir.setMap(dir.getMap());
        dir.setSize(dir.getSize());
        dir.save("1");


        dir.delete(doc4put.getDocName());


    }
}
