package hk.edu.polyu.comp.comp2021.cvfs.model;

import org.junit.Test;

public class CVFSTest {

    @Test
    public void testCVFSConstructor() {
        CVFS cvfscon = new CVFS();
        Disk diskcon = new Disk(1024);
    }
    @Test
    public void testCVFSsetandGet(){
        CVFS cvfs = new CVFS();
        Disk disk = new Disk(2048);
        cvfs.setDisk(disk);
        Disk got=cvfs.getDisk();
        cvfs.setDir(disk.getDir());
        Directory gotD=cvfs.getDir();
        assert true;
    }

}