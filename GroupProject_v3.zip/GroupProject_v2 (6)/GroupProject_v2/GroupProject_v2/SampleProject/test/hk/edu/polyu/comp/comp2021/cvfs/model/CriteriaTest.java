package hk.edu.polyu.comp.comp2021.cvfs.model;
import org.junit.Test;
public class CriteriaTest {
    @Test
    public void testCriteriaConstructor() {
        Criteria cri1 = new Criteria("cir1", "name", "contains", "\"do\"");
    }
    @Test
    public void testCriteriaMatcher() {
        Criteria aa = new Criteria("aa", "name", "contains", "\"do\"");
        Criteria bb = new Criteria("bb", "size", ">", "20");
        Criteria cc = new Criteria("cc", "size", "<", "20");
        Criteria dd = new Criteria("dd", "size", ">=", "20");
        Criteria ee = new Criteria("rr", "size", "<=", "20");
        Criteria ff = new Criteria("ff", "size", "==", "20");
        Criteria gg = new Criteria("gg", "size", "!=", "20");
        Criteria aaa = new Criteria("aa", "name", "contains", "\"do\"");
        Criteria bba = new Criteria("bb", "type", "equals", "\"txt\"");
        compositeCriteria hh = new compositeCriteria("hh", aaa, "&&", bba);
        compositeCriteria ii = new compositeCriteria("ii", aaa, "||", bba);


        Document doc = new Document("doc1", "txt", "111");
        aa.matches(doc);
        bb.matches(doc);
        cc.matches(doc);
        dd.matches(doc);
        ee.matches(doc);
        ff.matches(doc);
        gg.matches(doc);
        hh.matches(doc);
        ii.matches(doc);

        Directory dir = new Directory("dir1");
        aa.matches(dir);
        bb.matches(dir);
        cc.matches(dir);
        dd.matches(dir);
        ee.matches(dir);
        ff.matches(dir);
        gg.matches(dir);
        hh.matches(dir);
        ii.matches(dir);

    }
    @Test
    public void testCriteriaStaticmethod() {
        Criteria.notOp("!!");
        Criteria.notOp(">");
        Criteria.notOp(">=");
        Criteria.notOp("<");
        Criteria.notOp("<=");
        Criteria.notOp("==");
        Criteria.notOp("!=");
        Criteria.getCriteria("name");
        Criteria.getAllCriteria();
    }
    @Test
    public void testCriteriaGetanbPrint(){
        Criteria get = new Criteria("get", "name", "contains", "\"do\"");

        get.getCriName();
        get.getAttrName();
        get.getOp();
        get.getVal();
        get.print();
    }
    @Test
    public void testCriteriaSaveandLoad(){
        Criteria save = new Criteria("save", "name", "contains", "\"do\"");
        save.save("Disk4save");
        save.load("Disk4save");

    }
}
