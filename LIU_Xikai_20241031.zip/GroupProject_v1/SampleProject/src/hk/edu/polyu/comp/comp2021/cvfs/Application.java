package hk.edu.polyu.comp.comp2021.cvfs;

import hk.edu.polyu.comp.comp2021.cvfs.model.CVFS;
import hk.edu.polyu.comp.comp2021.cvfs.model.Disk;

import java.util.Scanner;

public class Application {

    public static void main(String[] args){
        CVFS cvfs = new CVFS();
        // Initialize and utilize the system

        Scanner scanner = new Scanner(System.in);
        String command;
        String[] commandWords;

        System.out.println("Any command or 'quit' to quit.");

        while (true) {
            System.out.print("Command: ");
            command = scanner.nextLine();
            commandWords=command.split("\\s+");

            if (command.equalsIgnoreCase("quit")) {
                System.out.println("Terminate the execution of the system.");
                break;
            }

            if (commandWords[0].equals("newDisk")){
                int size=Integer.parseInt(commandWords[1]);
                Disk disk=new Disk(size);
                System.out.println("New disk created successfully.");
            }
        }

        scanner.close();
    }
}
