package hk.edu.polyu.comp.comp2021.cvfs.model;

public class CVFS {

    public CVFS(){}

}
