package hk.edu.polyu.comp.comp2021.cvfs.model;

public class Disk {
    private int size;
    public Disk(int diskSize){
        size=diskSize;
    }
}
