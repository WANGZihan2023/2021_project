package hk.edu.polyu.comp.comp2021.cvfs.model;

import java.util.HashSet;

public class Document {
    private String docName;
    private String docType;
    private String docContent;
    private int size;
    public HashSet<String> nameSet;

    public Document(String name,String type,String content){
        nameSet = new HashSet<>();
        setDocName(name);
        setType(type);
        setDocContent(content);
        size=40+content.length()*2;
    }
    public int getSize(){
        return size;
    }
    public String getDocContent(){
        return docContent;
    }
    public String listString(){
        String result="Name: "+docName+" type: "+docType+" size: "+size;
        return result;
    }
    public String getDocName(){
        return docName;
    }
    public String getDocType(){
        return docType;
    }


    public void setDocName(String name) {
        // Check if the name is valid: only letters and digits, and length <= 10
        if (name.length() <= 10 && name.matches("^[a-zA-Z0-9]+$")) {
            this.docName = name;
            nameSet.add(name);
        } else {
            System.out.println("The docName is invalid. It must be up to 10 characters long and contain only letters and digits.");
        }
    }

    public void setType(String type) {
        // Check if the type is one of the allowed types
        if (type.equals("txt") || type.equals("java") || type.equals("html") || type.equals("css")) {
            this.docType = type;
        } else {
            System.out.println("The type is invalid. Allowed types are: txt, java, html, css.");
        }
    }
    public void setDocContent(String content){
        this.docContent=content;
    }
}
